<?php

return [
    'className' => 'icon',
    'attributes' => [],
];
