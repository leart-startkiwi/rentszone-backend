<?php

return [
    'drag_drop_info' => 'Drag and drop on the left to change the order or parent of the categories.',
    'expand_all' => 'Expand all',
    'collapse_all' => 'Collapse all',
    'empty_text' => 'No categories found.',
    'delete_button' => 'Delete',
    'delete_modal' => [
        'title' => 'Delete Category',
        'message' => 'Are you sure you want to delete this category?',
    ],
];
