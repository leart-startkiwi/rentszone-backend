<?php

namespace Botble\Table;

use Yajra\DataTables\DataTables as BaseDataTables;

class DataTables extends BaseDataTables
{
}
