<?php

namespace Botble\Table;

use Yajra\DataTables\CollectionDataTable as BaseCollectionDataTable;

class CollectionDataTable extends BaseCollectionDataTable
{
}
